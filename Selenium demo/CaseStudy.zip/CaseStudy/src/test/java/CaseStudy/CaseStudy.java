package CaseStudy;

import WebElementsList.*;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Properties;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

@Test
public class CaseStudy {

	int day, year, postal;
	long phone;
	String Username, Password;
	String BrowserPath, BrowserName, Url, ExcelPath, ScreenshotPath;
	String Gname, Mname, Fname, gender, month, Add1, Add2, city, state, country, Relation, person;

	public void Casestd() throws Exception {

		FileInputStream Properties = new FileInputStream("src\\test\\java\\CaseStudy\\Data.properties");
		Properties prop = new Properties();
		// load the properties file
		prop.load(Properties);
		// create variables for getting properties file
		BrowserPath = prop.getProperty("browserpath");
		BrowserName = prop.getProperty("browsername");
		Url = prop.getProperty("url");
		ExcelPath = prop.getProperty("excelpath");
		System.setProperty(BrowserName, BrowserPath);

		ChromeOptions Options = new ChromeOptions();
		Options.addArguments("--disable-save");
		WebDriver driver = new ChromeDriver(Options);
		driver.manage().window().maximize();

		// creating object for extent report
		ExtentReports extent = new ExtentReports();
		ExtentSparkReporter spark = new ExtentSparkReporter("src\\test\\resources\\Reports\\report.html");
		// below code is used to store the report
		extent.attachReporter(spark);
		ExtentTest testcase = extent.createTest("OpenMrs.org");
		driver.get(Url);
		testcase.log(Status.INFO, "opened the url");

//Scenario 1 : Login
		WebElementList el = new WebElementList();

		File src = new File(ExcelPath);
		FileInputStream fs = new FileInputStream(src);
		// Creating a workbooks
		XSSFWorkbook workbook = new XSSFWorkbook(fs);
		XSSFSheet sheet = workbook.getSheetAt(0);// providing sheet index
		int noofrow = sheet.getLastRowNum();

		// return the row count,
		for (int i = 1; i <= noofrow; i++) {
			XSSFRow currentrow = sheet.getRow(i);
			Username = currentrow.getCell(0).getStringCellValue();
			Password = currentrow.getCell(1).getStringCellValue();
			el.Login(driver).sendKeys(Username);
			testcase.log(Status.INFO, "Username enterd");
			el.password(driver).sendKeys(Password);
			testcase.log(Status.INFO, "Password enterd");
			el.Location(driver).click();
			testcase.log(Status.INFO, "Location selected");
			el.LoginButton(driver).click();
			String expectedTitle = "Home";
			String ActualTitle = driver.getTitle();
			if (expectedTitle.equalsIgnoreCase(ActualTitle)) {
				testcase.log(Status.PASS, "Successfully Login");
			} else {
				testcase.log(Status.FAIL, "Login Faild");
			}
			
		}
		
		TakesScreenshot ts = (TakesScreenshot) driver;
		File Source = ts.getScreenshotAs(OutputType.FILE);
		File dest = new File("src\\test\\resources\\screenshots\\LoginStatus.png");
		FileHandler.copy(Source, dest);
		testcase.addScreenCaptureFromPath("src\\test\\resources\\screenshots\\LoginStatus.png");

//Scenario 2 : Register a patient

		// creating work book for excel sheet
		XSSFSheet sheet1 = workbook.getSheetAt(1);// providing sheet index
		int noofrow1 = sheet1.getLastRowNum();
		// return the row count,
		for (int j = 1; j <= noofrow1; j++) {
			XSSFRow currentrow1 = sheet1.getRow(j); // it is focus on current row based on i value.
			Gname = currentrow1.getCell(0).getStringCellValue();
			Mname = currentrow1.getCell(1).getStringCellValue();
			Fname = currentrow1.getCell(2).getStringCellValue();
			gender = currentrow1.getCell(3).getStringCellValue();
			day = (int) currentrow1.getCell(4).getNumericCellValue();
			month = currentrow1.getCell(5).getStringCellValue();
			year = (int) currentrow1.getCell(6).getNumericCellValue();
			Add1 = currentrow1.getCell(7).getStringCellValue();
			Add2 = currentrow1.getCell(8).getStringCellValue();
			city = currentrow1.getCell(9).getStringCellValue();
			state = currentrow1.getCell(10).getStringCellValue();
			country = currentrow1.getCell(11).getStringCellValue();
			postal = (int) currentrow1.getCell(12).getNumericCellValue();
			phone = (long) currentrow1.getCell(13).getNumericCellValue();
			Relation = currentrow1.getCell(14).getStringCellValue();
			person = currentrow1.getCell(15).getStringCellValue();

			RegisterAPatientList Patient = new RegisterAPatientList();
			Patient.RegisterAPatient(driver).click();
			// Patient name
			testcase.log(Status.INFO, "Enter Name");
			Patient.GivenName(driver).sendKeys(Gname);
			Patient.MiddleName(driver).sendKeys(Mname);
			Patient.FamilyName(driver).sendKeys(Fname);
			Patient.NextBtn(driver).click();
			testcase.log(Status.PASS, "Name entered");
			Thread.sleep(1000);

			// gender selection
			testcase.log(Status.INFO, "Select Gender");
			Select Gen = new Select(Patient.Gender(driver));
			Gen.selectByVisibleText(gender);
			Patient.NextBtn(driver).click();
			testcase.log(Status.PASS, "Gender selected");
			Thread.sleep(1000);

			// date of birth
			testcase.log(Status.INFO, "Select Date of birth");
			Patient.Day(driver).sendKeys(String.valueOf(day));
			Select mn = new Select(Patient.Month(driver));
			mn.selectByVisibleText(month);
			Patient.Year(driver).sendKeys(String.valueOf(year));
			Patient.NextBtn(driver).click();
			testcase.log(Status.PASS, "Date of birth selected");
			Thread.sleep(1000);

			// address
			testcase.log(Status.INFO, "Enter Address");
			Patient.Address1(driver).sendKeys(Add1);
			Patient.Address2(driver).sendKeys(Add2);
			Patient.City(driver).sendKeys(city);
			Patient.State(driver).sendKeys(state);
			Patient.Country(driver).sendKeys(country);
			Patient.PostalCode(driver).sendKeys(String.valueOf(postal));
			Patient.NextBtn(driver).click();
			testcase.log(Status.PASS, "Address Enterd");
			Thread.sleep(1000);

			// Phone number
			testcase.log(Status.INFO, "Enter Phone number");
			Patient.PhoneNumber(driver).sendKeys(String.valueOf(phone));
			Patient.NextBtn(driver).click();
			testcase.log(Status.PASS, "Phone number Enterd");
			Thread.sleep(1000);

			// Relationship
			testcase.log(Status.INFO, "Select Relationship");
			Patient.ReletionShip(driver).sendKeys(Relation);
			Patient.Person(driver).sendKeys(person);
			Patient.NextBtn(driver).click();
			testcase.log(Status.PASS, "Relationship Selected");

			ts = (TakesScreenshot) driver;
			Source = ts.getScreenshotAs(OutputType.FILE);
			dest = new File("src\\test\\resources\\screenshots\\Patient Reg.png");
			FileHandler.copy(Source, dest);
			testcase.addScreenCaptureFromPath("src\\test\\resources\\screenshots\\Patient Reg.png");

			// Confirm
			Patient.ConfirmBtn(driver).click();
			testcase.log(Status.PASS, "Patient Registered Successfully");

		}
		Thread.sleep(15000);
		// Below code is used to get currently registered patient id
		String id = el.PatirntId(driver).getText();
		System.out.println(id);

		// Navigate to home page
		el.Home(driver).click();

//Scenario 3 : Find Patient Record

		testcase.log(Status.INFO, "Click Find Patient Records");
		el.FindRecord(driver).click();
		testcase.log(Status.PASS, "Patient Records Founed");
		Thread.sleep(3000);
		ts = (TakesScreenshot) driver;
		Source = ts.getScreenshotAs(OutputType.FILE);
		dest = new File("src\\test\\resources\\screenshots\\Find Patient.png");
		FileHandler.copy(Source, dest);
		testcase.addScreenCaptureFromPath("src\\test\\resources\\screenshots\\Find Patient.png");

//Scenario 4 : Search Patient Record

		testcase.log(Status.INFO, "Search Patient Records");
		el.SearchRecord(driver).sendKeys(id);
		testcase.log(Status.PASS, "Patient Records Founded");

		ts = (TakesScreenshot) driver;
		Source = ts.getScreenshotAs(OutputType.FILE);
		dest = new File("src\\test\\resources\\screenshots\\Find Patient.png");
		FileHandler.copy(Source, dest);
		testcase.addScreenCaptureFromPath("src\\test\\resources\\screenshots\\Find Patient.png");
		testcase.log(Status.INFO, "View the Patient Record");

//Scenario 5 : View Patient Record

		Robot r1 = new Robot();
		Toolkit.getDefaultToolkit().getSystemSelection();
		r1.keyPress(KeyEvent.VK_ENTER);
		r1.keyRelease(KeyEvent.VK_ENTER);
		testcase.log(Status.PASS, "Patient record Viewed");
		ts = (TakesScreenshot) driver;
		Source = ts.getScreenshotAs(OutputType.FILE);
		dest = new File("src\\test\\resources\\screenshots\\Patient.png");
		FileHandler.copy(Source, dest);
		testcase.addScreenCaptureFromPath("src\\test\\resources\\screenshots\\Patient.png");

//Scenario 6 : Book Appointment 
		Thread.sleep(2000);
		testcase.log(Status.INFO, "Click book appointment");
		BookAppointmentList BAL = new BookAppointmentList();
		BAL.BookAppointment(driver).click();
		BAL.Book(driver).sendKeys("General Medicine (New Patient)");

		Thread.sleep(3000);
		r1.keyPress(KeyEvent.VK_ENTER);
		r1.keyRelease(KeyEvent.VK_ENTER);

		BAL.Provider(driver).sendKeys("Jake Smith");
		Thread.sleep(3000);
		r1.keyPress(KeyEvent.VK_ENTER);
		r1.keyRelease(KeyEvent.VK_ENTER);
		BAL.Save(driver).click();
		testcase.log(Status.PASS, "Appointment Booked");
		ts = (TakesScreenshot) driver;
		Source = ts.getScreenshotAs(OutputType.FILE);
		dest = new File("src\\test\\resources\\screenshots\\Appointment booked.png");
		FileHandler.copy(Source, dest);
		testcase.addScreenCaptureFromPath("src\\test\\resources\\screenshots\\Appointment booked.png");

		// Set visit
		testcase.log(Status.INFO, "Set the visit");
		Thread.sleep(3000);
		BAL.SetVisit(driver).click();
		Thread.sleep(2000);
		r1.keyPress(KeyEvent.VK_ENTER);
		r1.keyRelease(KeyEvent.VK_ENTER);
		testcase.log(Status.PASS, "Set vist actived");
		Thread.sleep(5000);

//Scenario 7 : Capture Vitals

		CaptureVitalList Vitals = new CaptureVitalList();
		Vitals.CaptureVital(driver).click();
		testcase.log(Status.INFO, "Start Captureing vital");

		XSSFSheet sheet2 = workbook.getSheetAt(2);// providing sheet index
		int noofrow2 = sheet1.getLastRowNum();

		for (int k = 1; k <= noofrow2; k++) {
			XSSFRow currentrow2 = sheet2.getRow(k);
			int Height = (int) currentrow2.getCell(0).getNumericCellValue();
			int Weight = (int) currentrow2.getCell(1).getNumericCellValue();
			int Temp = (int) currentrow2.getCell(2).getNumericCellValue();
			int pulse = (int) currentrow2.getCell(3).getNumericCellValue();
			int RespRate = (int) currentrow2.getCell(4).getNumericCellValue();
			int BloodHigh = (int) currentrow2.getCell(5).getNumericCellValue();
			int Bloodlow = (int) currentrow2.getCell(6).getNumericCellValue();
			int pulseOximeter = (int) currentrow2.getCell(7).getNumericCellValue();

			testcase.log(Status.INFO, "Capture Heignt");
			Vitals.CaptureHeight(driver).sendKeys(String.valueOf(Height));
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			testcase.log(Status.INFO, "Capture Weight");
			Vitals.CaptureWeight(driver).sendKeys(String.valueOf(Weight));
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			testcase.log(Status.INFO, "Capture BMI");
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			testcase.log(Status.INFO, "Capture Temperature");
			Vitals.CaptureTemp(driver).sendKeys(String.valueOf(Temp));
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			testcase.log(Status.INFO, "Capture Pulse");
			Vitals.CapturePulse(driver).sendKeys(String.valueOf(pulse));
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			testcase.log(Status.INFO, "Capture Respiratory Rate");
			Vitals.CaptureResprate(driver).sendKeys(String.valueOf(RespRate));
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			testcase.log(Status.INFO, "Capture Blood Presure");
			Vitals.CaptureBloodPresure1(driver).sendKeys(String.valueOf(BloodHigh));
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Vitals.CaptureBloodPresure2(driver).sendKeys(String.valueOf(Bloodlow));
			Thread.sleep(1000);
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			testcase.log(Status.INFO, "Capture pulse oximeter");
			Vitals.CapturePulseOximeter(driver).sendKeys(String.valueOf(pulseOximeter));
			Thread.sleep(1000);
			Vitals.CaptureVitalNextBtn(driver).click();

		}
		ts = (TakesScreenshot) driver;
		Source = ts.getScreenshotAs(OutputType.FILE);
		dest = new File("src\\test\\resources\\screenshots\\After Capture Vitals.png");
		FileHandler.copy(Source, dest);
		testcase.addScreenCaptureFromPath("src\\test\\resources\\screenshots\\After Capture Vitals.png	");
		Thread.sleep(2000);
		Vitals.CaptureVitalSaveBtn(driver).click();
		testcase.log(Status.PASS, "Vitals Captured Successfully");
		Thread.sleep(2000);	

//Cookies handling

		File file = new File("src\\test\\resources\\Cookies\\cookies.data");
		try {
			// create new file
			file.createNewFile();
			// Write the file
			FileWriter fw = new FileWriter(file); // it is used to write the data char by char
			// Buffer writer is used to handle tacking time to write the file char by char
			BufferedWriter bwriter = new BufferedWriter(fw);

			// web site have more number of cookies so,Iterate One by one, by using for loop
			for (Cookie cki : driver.manage().getCookies()) {

				// after getting the cookies write all cookies in cookies.data file
				bwriter.write("Cookie name : " + cki.getName() + " Cookie Domain : " + cki.getDomain()
						+ " Cookie Path : " + cki.getPath() + " Cookie Value : " + cki.getValue() + " Cookie Expiry : "
						+ cki.getExpiry() + " Cookie Security : " + cki.isSecure());
				bwriter.newLine();
			}
			// below line of code is used to recollect the expired cookies
			Cookie ck1 = new Cookie("name", "value");
			driver.manage().addCookie(ck1);

			bwriter.close();
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}

//Scenario 8 : Logout

		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.icon-signout',':before').click()");
		String LogEpt = "Login";
		String LogAct = driver.getTitle();
		
		if (LogEpt.equalsIgnoreCase(LogAct)) {
			testcase.log(Status.PASS, "Logout Successfully");
		} else {
			testcase.log(Status.FAIL, "Logout Faild");
		}

		extent.flush();
	}
}
