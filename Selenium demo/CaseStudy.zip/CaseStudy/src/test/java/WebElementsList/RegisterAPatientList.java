package WebElementsList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class RegisterAPatientList {

	@Test
	public WebElement RegisterAPatient(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='content']/div[3]/div/a[4]"));

	}

	@Test
	public WebElement GivenName(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='demographics-name']/div/p/input"));

	}

	@Test
	public WebElement MiddleName(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='demographics-name']/div/p[2]/input"));

	}

	@Test
	public WebElement FamilyName(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='demographics-name']/div/p[3]/input"));

	}

	@Test
	public WebElement NextBtn(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='next-button']"));

	}

	@Test
	public WebElement Gender(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='registration']/section/div/fieldset[2]/p/select"));

	}

	@Test
	public WebElement Day(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='demographics-birthdate']/p[2]/input"));
	}

	@Test
	public WebElement Month(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='demographics-birthdate']/p[3]/select"));
	}

	@Test
	public WebElement Year(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='demographics-birthdate']/p[4]/input"));
	}

	@Test
	public WebElement Address1(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='contactInfo']/div/fieldset/p[2]/input"));

	}

	@Test
	public WebElement Address2(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='contactInfo']/div/fieldset/p[4]/input"));

	}

	@Test
	public WebElement City(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='contactInfo']/div/fieldset/p[6]/input"));

	}

	@Test
	public WebElement State(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='contactInfo']/div/fieldset/p[7]/input"));

	}

	@Test
	public WebElement Country(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='contactInfo']/div/fieldset/p[8]/input"));

	}

	@Test
	public WebElement PostalCode(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='contactInfo']/div/fieldset/p[9]/input"));

	}

	@Test
	public WebElement PhoneNumber(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='phoneNumberLabel']/p/input"));

	}

	@Test
	public WebElement ReletionShip(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='relationship']/p/select"));

	}

	@Test
	public WebElement Person(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='relationship']/p[2]/input"));

	}

	@Test
	public WebElement ConfirmBtn(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='confirmationQuestion']/p/input"));

	}

	@Test
	public WebElement Confirm(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='confirmation']/div/div/p"));

	}

}
