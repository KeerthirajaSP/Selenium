package WebElementsList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class CaptureVitalList {
	@Test
	public WebElement CaptureVital(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='visit-details']/div[2]/a[4]"));

	}

	@Test
	public WebElement CaptureHeight(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[1]/p/span/input"));

	}
	@Test
	public WebElement CaptureVitalNextBtn(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='next-button']"));

	}

	@Test
	public WebElement CaptureWeight(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[2]/p/span/input"));

	}

	@Test
	public WebElement CaptureBMI(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[3]/p/input"));

	}

	@Test
	public WebElement CaptureTemp(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[4]/p/span/input"));

	}

	@Test
	public WebElement CapturePulse(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[5]/p/span/input"));

	}

	@Test
	public WebElement CaptureResprate(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[6]/p/span/input"));

	}

	@Test
	public WebElement CaptureBloodPresure1(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[7]/p[1]/span/input"));

	}

	@Test
	public WebElement CaptureBloodPresure2(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[7]/p[3]/span/input"));

	}
	@Test
	public WebElement CapturePulseOximeter(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='vitals']/fieldset[8]/p[1]/span/input"));

	}
	@Test
	public WebElement CaptureVitalSaveBtn(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='confirmationQuestion']/p[1]/button"));

	}
	
}
