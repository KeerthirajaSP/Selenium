package WebElementsList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class BookAppointmentList {
	@Test
	public WebElement BookAppointment(WebDriver driver) {

		return driver.findElement(By.xpath("//ul[@class='float-left']/li[5]/a"));
	}

	@Test
	public WebElement Book(WebDriver driver) {

		return driver.findElement(By.xpath("//*[@id='appointment-type']"));
	}

	@Test
	public WebElement Provider(WebDriver driver) {

		return driver.findElement(By.xpath("//*[@id='provider']"));
	}

	@Test
	public WebElement Save(WebDriver driver) {

		return driver.findElement(By.xpath("//*[@id='save-button']"));
	}

	@Test
	public WebElement SetVisit(WebDriver driver) {

		return driver.findElement(By.xpath("//ul[@class='float-left']/li[1]/a"));
	}

	@Test
	public WebElement SetVisitConfBtn(WebDriver driver) {

		return driver.findElement(By.xpath("//ul[@id='start-visit-with-visittype-confirm']"));
	}

}
