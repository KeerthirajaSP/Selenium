package WebElementsList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class WebElementList {
	@Test
	public WebElement Login(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='username']"));

	}

	@Test
	public WebElement password(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='password']"));

	}

	@Test
	public WebElement Location(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='Inpatient Ward']"));

	}

	@Test
	public WebElement LoginButton(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='loginButton']"));

	}

	@Test
	public WebElement Home(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='breadcrumbs']/li/a"));

	}

	@Test
	public WebElement FindRecord(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='apps']/a"));

	}

	@Test
	public WebElement PatirntId(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='body-wrapper']/div[3]/div[6]/div[2]/div/span"));

	}

	@Test
	public WebElement SearchRecord(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='patient-search-form']/input"));

	}

	@Test
	public WebElement PatientRecord(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id='patient-search-results-table']/tbody/tr"));

	}

}
