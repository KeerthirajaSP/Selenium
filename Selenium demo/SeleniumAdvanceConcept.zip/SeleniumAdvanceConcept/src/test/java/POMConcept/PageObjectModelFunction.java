package POMConcept;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class PageObjectModelFunction {
  @Test
  public void POM() {
	  System.setProperty("webdriver.chrome.driver", "src//test//resources//utility//chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://demo.automationtesting.in/SignIn.html");
	  WebElementsList emt=new WebElementsList();//importing from WebElementsList class
	  emt.Login(driver).sendKeys("keerthiraja");
	  emt.password(driver).sendKeys("keerthiraja@123");
	  emt.EnterBtn(driver).click();
  }
}
