package POMConcept;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class WebElementsList {
  @Test
  public WebElement Login(WebDriver driver) {
	return driver.findElement(By.xpath("//*[@class='txtbox ng-pristine ng-untouched ng-valid']"));
  
  }
  @Test
  public WebElement password(WebDriver driver) {
	return driver.findElement(By.xpath("//*[@type='password']"));
  
  }
  @Test
  public WebElement EnterBtn(WebDriver driver) {
	return driver.findElement(By.xpath("//*[@id='enterbtn']"));
  
  }
}
