package OptionsConcept;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeOptions;
public class ChromeOption {
  @Test
  public void ChromeOptions() {
	  
	  System.setProperty("webdriver.chrome.driver", "src//test//resources//utility//chromedriver.exe");
//chrome option is used to handle the browser settings
	  ChromeOptions ch = new ChromeOptions();
	  ch.setAcceptInsecureCerts(true);
//below argument is used to handle the incognito mode in browser
	  ch.addArguments("incognito");
//-- hand less is used to run the script background
	  ch.addArguments("--handless");
//used to disable notification
	  ch.addArguments("--disable-notifications");
	 //used to disable location based notification
	  ch.addArguments("--disable-geolocation");
	  //used to disable media stream
	  ch.addArguments("--disable-media-stream");
	  //used to disable pop up
	  ch.addArguments("--disable-popup-blocking");
	  //used to disable information bar
	  ch.addArguments("--disable-infobars");
	  WebDriver driver =new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://badss1.com/");
//handle the in secured web page
	  driver.findElement(By.linkText("wrong.host")).click();
	  
	  
  }
}
