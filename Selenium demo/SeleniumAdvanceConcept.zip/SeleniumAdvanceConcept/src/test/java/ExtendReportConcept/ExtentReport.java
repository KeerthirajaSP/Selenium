package ExtendReportConcept;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {
	@Test
	public void ExtentReports() throws IOException {
		System.setProperty("webdriver.chrome.driver", "src//test//resources//utility//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		// creating object for extent report
		ExtentReports extent = new ExtentReports();

		ExtentSparkReporter spark = new ExtentSparkReporter("src\\test\\resources\\reports\\report.html");
		// below code is used to store the report
		extent.attachReporter(spark);
		ExtentTest testcase = extent.createTest("Vertify title");

		driver.get("https://leafground.com/");
		testcase.log(Status.INFO, "opened the url");
		String expectedTitle = "Dashboard";
		testcase.log(Status.INFO, "Expected Title is saved");
		String ActualTitle = driver.getTitle();
		testcase.log(Status.INFO, "Actual Title returned from the browser");

		if (expectedTitle.equalsIgnoreCase(ActualTitle)) {
			System.out.println("Title matching");
			testcase.log(Status.PASS, "Title matching");
		} else {
			testcase.log(Status.FAIL, "title not matching");

		}
		TakesScreenshot ts = (TakesScreenshot) driver;
		File Source = ts.getScreenshotAs(OutputType.FILE);
		File dest = new File("src\\test\\resources\\utility\\screenshots\\ExtentReports.png");
		FileHandler.copy(Source, dest);
		testcase.addScreenCaptureFromPath("src\\test\\utlity\\resources\\screenshots\\ExtentReports.png");
		extent.flush();
	}
}
