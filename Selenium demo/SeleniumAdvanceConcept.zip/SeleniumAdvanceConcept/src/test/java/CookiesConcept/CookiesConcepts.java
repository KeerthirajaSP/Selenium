package CookiesConcept;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class CookiesConcepts {
	@Test
	public void Cookies() throws IOException {
// create the object for properties file is where it is located
		FileInputStream Properties = new FileInputStream("src\\test\\resources\\utility\\Config.properties");
		Properties prop = new Properties();
// load the properties file
		prop.load(Properties);
// create variables for getting properties file
		String BrowserPath = prop.getProperty("browserpath");
		String BrowserName = prop.getProperty("browsername");
		String Url = prop.getProperty("cookiesUrl");
		System.setProperty(BrowserName, BrowserPath);
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(Url);

		File file=new File("src\\test\\resources\\utility\\cookies.data");
		try {
	//create new file 
			file.createNewFile();
	//Write the file 
			FileWriter fw=new FileWriter(file); // it is used to write the data char by char
	//Buffer writer is used to handle tacking time to write the file char by char		
			BufferedWriter bwriter=new BufferedWriter(fw);
			
	//web site have more number of cookies so,Iterate One by one by using for loop
			for(Cookie cki:driver.manage().getCookies()) {
			
	//after getting the cookies write all cookies in cookies.data file
				bwriter.write("Cookie name : "+cki.getName()+" Cookie Domain : "+cki.getDomain()+" Cookie Path : "+cki.getPath()+" Cookie Value : "+cki.getValue()+" Cookie Expiry : "+cki.getExpiry()+" Cookie Security : "+cki.isSecure());
				bwriter.newLine();
			}
	//below line of code is used to recollect the expired cookies 
			Cookie ck1=new Cookie("name","value");
			driver.manage().addCookie(ck1);
			
			bwriter.close();
			fw.close();
		}catch (Exception e) {
			System.out.println(e);
		}
		
	}
}
