package PageFactoryModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ElementsList {
	
	@FindBy(xpath="//*[@class='txtbox ng-pristine ng-untouched ng-valid']")
	public static WebElement Login;
	@FindBy(xpath="//*[@type='password']")
	public static WebElement password;
	@FindBy(xpath="//*[@id='enterbtn']")
	public static WebElement EnterBtn;
	
}
