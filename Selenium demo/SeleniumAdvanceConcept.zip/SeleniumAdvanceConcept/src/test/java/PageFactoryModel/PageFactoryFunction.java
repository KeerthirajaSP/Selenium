package PageFactoryModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

public class PageFactoryFunction {
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", "src//test//resources//utility//chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://demo.automationtesting.in/SignIn.html");
	  PageFactory.initElements(driver, ElementsList.class);
	  ElementsList.Login.sendKeys("keerthiraja");
	  ElementsList.password.sendKeys("keerthiraja@123");
	  ElementsList.EnterBtn.click();
  }
}
