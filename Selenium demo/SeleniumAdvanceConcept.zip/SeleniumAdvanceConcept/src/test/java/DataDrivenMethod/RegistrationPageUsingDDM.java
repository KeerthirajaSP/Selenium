package DataDrivenMethod;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class RegistrationPageUsingDDM {

	@Test
	public void f() throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver","src//test//resources//utility//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.automationtesting.in/Register.html");
		// Path of the excel file
		FileInputStream fs = new FileInputStream(
				"C:\\Users\\keerthiraja.sp\\OneDrive - HCL Technologies Ltd\\Desktop\\Registration.xlsx");
		// Creating a workbooks
		XSSFWorkbook workbook = new XSSFWorkbook(fs); // creating work book for excel sheet
		XSSFSheet sheet = workbook.getSheet("Registration");// providing sheet name
		int noofrow = sheet.getLastRowNum();// return the row count,
		for (int i = 1; i <= noofrow; i++) {
			XSSFRow currentrow = sheet.getRow(i); // it is focus on current row based on i value.
			String Firstname = currentrow.getCell(0).getStringCellValue();
			String Lastname = currentrow.getCell(1).getStringCellValue();
			String Address = currentrow.getCell(2).getStringCellValue();
			String Email = currentrow.getCell(3).getStringCellValue();
			long Phone = (long) currentrow.getCell(4).getNumericCellValue();
			String gender = currentrow.getCell(5).getStringCellValue();
			String hobbies = currentrow.getCell(6).getStringCellValue();
			String Language = currentrow.getCell(7).getStringCellValue();
			String Skills = currentrow.getCell(8).getStringCellValue();
			String Country = currentrow.getCell(9).getStringCellValue();
			int year = (int) currentrow.getCell(10).getNumericCellValue();
			String month = currentrow.getCell(11).getStringCellValue();
			int date = (int) currentrow.getCell(12).getNumericCellValue();
			// Registration process
			// Entering contact information
			driver.findElement(By.xpath("//*[@ng-model='FirstName']")).sendKeys(Firstname);
			driver.findElement(By.xpath("//*[@ng-model='LastName']")).sendKeys(Lastname);
			driver.findElement(By.xpath("//*[@ng-model='Adress']")).sendKeys(Address);
			driver.findElement(By.xpath("//*[@type='email']")).sendKeys(Email);
			// Send keys method not allow the numeric values so, we are using
			// string.valueof();
			driver.findElement(By.xpath("//*[@type='tel']")).sendKeys(String.valueOf(Phone));

			Thread.sleep(2000);
			List<WebElement> genLable = driver.findElements(By.xpath("//*[@id='basicBootstrapForm']/div[5]/div/label"));

			for (WebElement s : genLable) {

				if (s.getText().equalsIgnoreCase(gender)) {
					driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[5]/div/label[1]/input")).click();
					break;
				} else {
					driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[5]/div/label[2]/input")).click();
					break;
				}
			}

			List<WebElement> Hby = driver.findElements(By.xpath("//*[@id='basicBootstrapForm']/div[6]/div/div/label"));

			for (int h = 1; h <= Hby.size(); h++) {
				String Ha = Hby.get(h).getText();
				if (Ha.equalsIgnoreCase(hobbies)) {
					driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[6]/div/div[" + h + "]/input"))
							.click();
					break;
				}
			}

			// Entering the language by selecting drop down method
			driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[7]/div/multi-select/div")).click();
			Thread.sleep(3000);
			WebElement dropdown = driver
					.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[7]/div/multi-select/div[2]/ul"));
			List<WebElement> dp = dropdown.findElements(By.tagName("li"));
			for (WebElement s : dp) {
				if (s.getText().equalsIgnoreCase(Language)) {
					s.click();
					break;
				}
			}
			// Entering the Skills by select drop down method
			Select dropSkill = new Select(
					driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[8]/div/select")));
			dropSkill.selectByVisibleText(Skills);
			// Entering the country by select drop down method
			Select ctry = new Select(
					driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[10]/div/select")));
			ctry.selectByVisibleText(Country);

			Select yr = new Select(driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[11]/div/select")));
			yr.selectByVisibleText(String.valueOf(year));

			Select mn = new Select(driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[11]/div[2]/select")));
			mn.selectByVisibleText(month);

			Select dy = new Select(driver.findElement(By.xpath("//*[@id='basicBootstrapForm']/div[11]/div[3]/select")));
			dy.selectByVisibleText(String.valueOf(date));
		}
	}
}
