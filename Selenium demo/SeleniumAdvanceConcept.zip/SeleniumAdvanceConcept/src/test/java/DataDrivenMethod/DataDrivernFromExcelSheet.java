package DataDrivenMethod;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DataDrivernFromExcelSheet {
  @Test
  public void DataDrivenLoginPage() throws IOException {
	  System.setProperty("webdriver.chrome.driver", "src//test//resources//utility//chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://demo.automationtesting.in/SignIn.html");
	//Path of the excel file
	  FileInputStream fs = new FileInputStream("C:\\Users\\keerthiraja.sp\\OneDrive - HCL Technologies Ltd\\Desktop\\Registration.xlsx");
	  //Creating a workbooks
	  XSSFWorkbook workbook = new XSSFWorkbook(fs); //creating work book for excel sheet
	  XSSFSheet sheet = workbook.getSheet("Login");// providing sheet name 
	  int noofrow=sheet.getLastRowNum();// return the row count
	  
	  for(int i=1; i< noofrow; i++){
		  	XSSFRow row=sheet.getRow(i);
		  	String Login= row.getCell(i).getStringCellValue();
			String Password= row.getCell(i).getStringCellValue();
			driver.findElement(By.xpath("//*[@class='txtbox ng-pristine ng-untouched ng-valid']")).sendKeys(Login);
			driver.findElement(By.xpath("//*[@type='password']")).sendKeys(Password);
			driver.findElement(By.xpath("//*[@id='enterbtn']")).click();
	  }
	 
  }
}
