package RadioButton;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class RadioButtonHandsOn {
  @Test
  public void RadioButton() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/radio.xhtml;jsessionid=node01nu0q9ndg6an0cxgqf5ic44mm200587.node0");
	//Select Age group only if not selected
			List<WebElement>agegroup=driver.findElements(By.xpath("//*[@id='j_idt87:age']/div/div/div/div/input"));
			List<WebElement>ageLable=driver.findElements(By.xpath("//*[@id='j_idt87:age']/div/div/label"));
			for(int i=1;i<agegroup.size();i++) {
				
				if(agegroup.get(i).isSelected()) {
					System.out.println("Selected age group is : "+ageLable.get(i).getText());
					String text=ageLable.get(i).getText();

					Thread.sleep(2000);
					if(text.equalsIgnoreCase("1-20 Years")) {
						System.out.println("My age group is selected");
					}
					else {
						Thread.sleep(2000);
						WebElement myage=driver.findElement(By.xpath("//label[text()='1-20 Years']/preceding-sibling::div/div[2]"));
						myage.click();
						System.out.println("My age group 1 to 20 is selected");
					}
				}
			
			}
			}
  }

