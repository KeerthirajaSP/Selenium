package RadioButton;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class RadioButton {
  @Test
  public void RadioButtons() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/radio.xhtml;jsessionid=node01nu0q9ndg6an0cxgqf5ic44mm200587.node0");
	//Select radio button	
		driver.findElement(By.xpath("//label[text()='Chrome']/preceding-sibling::div/div[2]")).click();
	//Find selected Radio button
		List<WebElement>radio=driver.findElements(By.xpath("//*[@id='j_idt87:console2']/tbody/tr/td/div/input"));
		List<WebElement>Lable=driver.findElements(By.xpath("//*[@id='j_idt87:console2']/tbody/tr/td/div/lable"));
		for(int i=1;i<radio.size();i++) {
			
			if(radio.get(i).isSelected()) {
				System.out.println("defaut selected radio buttion : "+Lable.get(i).getText());
			}
		}
	//Select Age group only if not selected
		List<WebElement>agegroup=driver.findElements(By.xpath("//*[@id='j_idt87:age']/div/div/div/div/input"));
		List<WebElement>ageLable=driver.findElements(By.xpath("//*[@id='j_idt87:age']/div/div/label"));
		for(int i=1;i<agegroup.size();i++) {
			
			if(agegroup.get(i).isSelected()) {
				System.out.println("Selected age group is : "+ageLable.get(i).getText());
			}
		}
  }
}
