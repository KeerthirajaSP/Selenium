package CheckBox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class CheckBoxhandsOn {
  @Test
  public void Notification() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(" https://leafground.com/checkbox.xhtml");
	 WebElement notification= driver.findElement(By.xpath("//*[@id='j_idt87:j_idt91']/div[2]"));
		
		for(int i=0;i<2;i++) {
			notification.click();
			Thread.sleep(2000);
			String msg=driver.findElement(By.xpath("/html/body/div[5]/div/div/div[2]/span")).getText();
			
			System.out.println("Notification checkBox : "+msg);
		}	
		WebElement Toggle= driver.findElement(By.xpath("//*[@id='j_idt87:j_idt100']/div[2]"));
			
			for(int i=0;i<2;i++) {
				Toggle.click();
				Thread.sleep(2000);
				String tgl=driver.findElement(By.xpath("/html/body/div[5]/div/div/div[2]/span")).getText();
				System.out.println("Toggle checkBox : "+tgl);
			}	
		Boolean dissable= driver.findElement(By.xpath("//*[@id='j_idt87:j_idt102']")).isEnabled();
		System.out.println(dissable);
		driver.findElement(By.xpath("//*[@class='ui-selectcheckboxmenu-trigger ui-state-default ui-corner-right']")).click();
		 Thread.sleep(10000);		  
		 		WebElement checkbox = driver.findElement(By.xpath("//label[text()='Rome']/preceding-sibling::div/div[2]"));
		 		checkbox.click();
  }
}
