package CheckBox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SelectMultipleCheckBox {
  @Test
  public void f() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(" https://leafground.com/checkbox.xhtml");
		 driver.findElement(By.xpath("//*[@class='ui-selectcheckboxmenu-trigger ui-state-default ui-corner-right']")).click();
		 Thread.sleep(10000);		  
		 		WebElement checkbox = driver.findElement(By.xpath("//label[text()='Rome']/preceding-sibling::div/div[2]"));
		 		checkbox.click();
  }
}
