package TackingScreensort;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class Screensort {
	@BeforeMethod
	public void Before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	}
  @Test
  public void ScreensortByUsingFileMethod() throws IOException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/charts.xhtml");
		TakesScreenshot ts=(TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		File dest=new File("C:\\Users\\keerthiraja.sp\\OneDrive - HCL Technologies Ltd\\Pictures\\chart.png");
		FileHandler.copy(source,dest);
		driver.close();
  }
  @Test
  public void ScreensortByUsingRobotClass() throws IOException, AWTException {
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/charts.xhtml");
		Robot r1=new Robot();
		Dimension dim=Toolkit.getDefaultToolkit().getScreenSize();
		Rectangle rect=new Rectangle(dim);
		BufferedImage src=r1.createScreenCapture(rect);
		File dest1=new File("C:\\Users\\keerthiraja.sp\\OneDrive - HCL Technologies Ltd\\Pictures\\chartRbt.png");
		ImageIO.write(src, "png", dest1);
		driver.close();
  }
}
