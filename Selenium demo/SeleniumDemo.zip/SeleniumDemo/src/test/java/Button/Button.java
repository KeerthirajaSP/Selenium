package Button;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Button {
	public class ButtonHandson {
		@BeforeMethod
		public void Before() {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");

		}
  @Test
  public void Button() throws InterruptedException {
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/button.xhtml");
		driver.findElement(By.id("j_idt88:j_idt90")).click();
		driver.navigate().back();
		boolean btn= driver.findElement(By.id("j_idt88:j_idt92")).isEnabled();
		if(btn==false) {
			System.out.println("the button is disabled");
		}
		Point btnLocation=driver.findElement(By.id("j_idt88:j_idt94")).getLocation();
		int btnx=btnLocation.getX();
		int btny=btnLocation.getY();
		System.out.println("Button position X axis is : "+ btnx +" and Y axix is "+ btny);
		String btnColor=driver.findElement(By.id("j_idt88:j_idt96")).getCssValue("background");
		System.out.println(btnColor);
		Dimension btnpadding=driver.findElement(By.id("j_idt88:j_idt98")).getSize();
		int height=btnpadding.getHeight();
		int width=btnpadding.getWidth();
		System.out.println("Height : "+height+" Width : "+width);
		
		//driver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
		//Thread.sleep(1000);
		driver.findElement(By.id("j_idt88:j_idt102:j_idt104")).click();
		
		
		
  }
  }
}
