package WebTable;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class WebTable {
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/table.xhtml");
		
		List<WebElement> columns=driver.findElements(By.xpath("//*[@role='grid']/tbody/tr/td"));
		System.out.println(columns.size());
		List<WebElement> rows=driver.findElements(By.xpath("//*[@role='grid']/tbody/tr"));
		System.out.println(rows.size());
		
		
  
  }
}
