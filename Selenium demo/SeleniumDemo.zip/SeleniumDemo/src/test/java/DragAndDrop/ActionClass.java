package DragAndDrop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class ActionClass {
  @Test
  public void f() {
	  	System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  	WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.hcltech.com/");
		WebElement src=driver.findElement(By.xpath("//*[@class='block-mainnavigationbt navnavbar-navlevel-0']/li[5]/a"));
		Actions act=new Actions(driver);
		act.moveToElement(src).build().perform();
		WebElement src1=driver.findElement(By.xpath("//*[@class='dropdown-menu level-1']/li/ul/li[3]/a"));
		act.moveToElement(src1).build().perform();
  }
}
