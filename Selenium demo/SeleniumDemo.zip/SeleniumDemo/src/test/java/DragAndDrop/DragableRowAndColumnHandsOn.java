package DragAndDrop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DragableRowAndColumnHandsOn {
	@BeforeMethod
	public void before() {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	}
  @Test
  public void DragAndDropColumn() throws InterruptedException {
	 
	  	WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/drag.xhtml;jsessionid=node0d1n8i6hkl0r914s6et6z3vyg2224514.node0");
	
	//Drag and drop the table column
		WebElement columnSRC=driver.findElement(By.id("form:j_idt94:j_idt95"));
		WebElement columnDST=driver.findElement(By.id("form:j_idt94:j_idt99"));
		Actions act=new Actions(driver);
		act.dragAndDrop(columnSRC,columnDST).build().perform();
		Thread.sleep(3000);
		String msg=driver.findElement(By.xpath("//*[@id='form:msgs_container']/div/div/div[2]")).getText();
		System.out.println("Column message is : "+msg);
		
	//Drag and drop the table row
		Thread.sleep(6000);
		WebElement drag1 = driver.findElement(By.xpath("//*[@id=\"form:j_idt111_data\"]/tr[3]"));
		 
		WebElement dest1 = driver.findElement(By.xpath("//*[@id=\"form:j_idt111_data\"]/tr[2]"));
 
		act.dragAndDrop(drag1, dest1).build().perform();
		Thread.sleep(3000);
		String msg1=driver.findElement(By.xpath("//*[@id='form:msgs_container']/div/div/div[2]")).getText();
		System.out.println("Row message is : "+msg1);
		
  }
  
}
