package DragAndDrop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class DragAndDrop {
  @Test
  public void DragAndDropAction() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/drag.xhtml;jsessionid=node09f6ssjr0rzx313qj4ygzb6yzi224521.node0");
		Actions act=new Actions(driver);
		WebElement src=driver.findElement(By.id("form:conpnl"));
		act.dragAndDropBy(src, 250, 0).build().perform();
	
		WebElement src1=driver.findElement(By.id("form:drag_content"));
		WebElement dst=driver.findElement(By.id("form:drop_content"));
		act.dragAndDrop(src1, dst).build().perform();;
		
		
  }
}
