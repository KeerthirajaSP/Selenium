package Menu;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class ContextMenu {
  @Test
  public void contextMenu() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/menu.xhtml;jsessionid=node0d5e8sw4235fa1wxcil8qpuz9n225158.node0");
	//context menu
			Thread.sleep(2000);
			Actions act3=new Actions(driver);
			act3.contextClick().build().perform();
  }
}
