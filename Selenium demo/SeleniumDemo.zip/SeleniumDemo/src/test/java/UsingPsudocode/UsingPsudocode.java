package UsingPsudocode;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class UsingPsudocode {
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.ksrtc.in/oprs-web/guest/home.do?h=1");
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("document.querySelector('.custom-control-label',':after').click()");
		
		
  }
}
