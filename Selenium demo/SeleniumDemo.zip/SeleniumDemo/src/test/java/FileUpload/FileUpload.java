package FileUpload;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FileUpload {
	@BeforeMethod
	public void before() {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	}
  @Test
  public void FileUploadsWithSendKeys() {
	 
	  	WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/file.xhtml");
	//Basic Upload
		driver.findElement(By.id("j_idt88:j_idt89_input")).sendKeys("C:\\Users\\keerthiraja.sp\\OneDrive - HCL Technologies Ltd\\Desktop\\Selenium Hands-on\\CheckBox hands-on.docx");
	//Advanced Upload - Only Pictures
		driver.findElement(By.id("j_idt97:j_idt98_input")).sendKeys("C:\\Users\\keerthiraja.sp\\OneDrive - HCL Technologies Ltd\\Pictures\\Screenshots\\Screenshot (657).png");
	//Basic Download
		driver.findElement(By.id("j_idt93:j_idt95")).click();
		
  }
  @Test
  public void FileUploadWithoutSendKeys() throws AWTException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.adobe.com/acrobat/online/convert-pdf.html");
		driver.findElement(By.id("lifecycle-nativebutton")).click();
		Robot r1=new Robot();
		String filepath="C:\\Users\\keerthiraja.sp\\OneDrive - HCL Technologies Ltd\\Desktop\\Selenium Hands-on\\CheckBox hands-on.docx";
		StringSelection select=new StringSelection(filepath);//Machine understanding language
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(select, null);
		r1.keyPress(KeyEvent.VK_CONTROL);
		r1.keyPress(KeyEvent.VK_V);
		r1.keyRelease(KeyEvent.VK_V);
		r1.keyRelease(KeyEvent.VK_CONTROL);
		r1.keyPress(KeyEvent.VK_ENTER);
		r1.keyRelease(KeyEvent.VK_ENTER);
		
  }
  @Test
  public void FileDownload() {
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/file.xhtml");
		driver.findElement(By.id("j_idt93:j_idt95")).click();
		File fi=new File("C:\\Users\\keerthiraja.sp\\Downloads");
		File[] listfile=fi.listFiles();
		for(File f:listfile) {
			if(f.getName().equalsIgnoreCase("TestLeaf Logo.png")) {
				System.out.println("File download successfully");
			}
		}
		
  }
}
