package TestNGAnotation;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;

public class dependOnMethod {
	
	@BeforeMethod
	public void Before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");

	}
	@Test
	public void homePage() {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com");
		String title= driver.getTitle();
		String acttitle="Dashboard";
		Assert.assertEquals(acttitle, title);
		
		
		
	}
  @Test(dependsOnMethods ="homePage")
  public void Textbox() {
	  WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com");
		driver.navigate().to("https://leafground.com/input.xhtml;jsessionid=node0sud0dhdfq8hnx8ngg3mlki73148012.node0");
		
  }
  
}
