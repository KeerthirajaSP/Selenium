package TestNGAnotation;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DataProvider {
public int add(int a, int b) {
	
	return a+b;
	
}

@Test(dataProvider="dp")
public void testadd(int a, int b, int exp) {
	DataProvider dp=new DataProvider();
	Assert.assertEquals(dp.add(a,b), exp);
	
	}
@org.testng.annotations.DataProvider(name="dp")
public Object[][] getdata(){
	Object[][] t= new Object[][] {
		
		{3,4,7},{6,9,15},{45,60,10}
			
		};
	return t;
	}
}

