package TestNGAnotation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Priority {
	
	@BeforeMethod
	public void Browser(){
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
		
	}
	@Test(priority = 1)
	public void Bf() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://leafground.com");
		String title= driver.getTitle();
		String acttitle="Dashboard";
		Assert.assertEquals(title, acttitle);
		
		
	}
  @Test(priority = 2)
  public void homePage() {
	  	WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com");
		driver.navigate().to("https://leafground.com/input.xhtml;jsessionid=node0sud0dhdfq8hnx8ngg3mlki73148012.node0");
		
  }
  @Test(priority = 0)
  public void Textbox() {
	  	WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com");
		driver.navigate().to("https://leafground.com/input.xhtml;jsessionid=node0sud0dhdfq8hnx8ngg3mlki73148012.node0");
		
  }
}
