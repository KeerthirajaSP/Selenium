package TestNGAnotation;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;

public class GroupMethod {
	@BeforeMethod(groups ="module")
	public void Before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");

	}
	@Test(groups ="module")
	public void homePage() {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com");
		String title= driver.getTitle();
		String acttitle="Dashboard";
		AssertJUnit.assertEquals(acttitle, title);
		
		
		
	}
  @Test
  public void Textbox() {
	  WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com");
		driver.navigate().to("https://leafground.com/input.xhtml;jsessionid=node0sud0dhdfq8hnx8ngg3mlki73148012.node0");
		
  }
  @Test(groups ="module")
  public void Button() {
	  WebDriver driver =new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com");
		driver.navigate().to("https://leafground.com/button.xhtml;jsessionid=node01qzmdox80lwn21tf1lsgwrlkqv148292.node0");
		
  }
  
}
