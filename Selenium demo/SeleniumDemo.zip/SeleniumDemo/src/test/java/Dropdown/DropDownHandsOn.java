package Dropdown;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DropDownHandsOn {
  @Test
  public void DropDown() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/select.xhtml;jsessionid=node01nu0q9ndg6an0cxgqf5ic44mm200587.node0");
	//1.Choose your preferred country
			driver.findElement(By.xpath("//*[@class='col-12']/div/div[3]/span")).click();
			Thread.sleep(2000);
			WebElement Li=driver.findElement(By.xpath("//*[@id='j_idt87:country_items']"));
			List<WebElement>Drop=Li.findElements(By.tagName("li"));
			String s1="India";
			for(WebElement s:Drop) {
				System.out.println(s.getText());
				if(s.getText().equalsIgnoreCase(s1)) {
					s.click();
					break;
				}
			}
    //2.Confirm Cities belongs to Country is loaded
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='j_idt87:city']/div[3]/span")).click();
			Thread.sleep(2000);
			WebElement cty=driver.findElement(By.xpath("//*[@id='j_idt87:city_panel']/div/ul"));
			List<WebElement>City=cty.findElements(By.tagName("li"));
			String city="Chennai";
			for(WebElement c:City) {
				System.out.println(c.getText());
				
				if(c.getText().equalsIgnoreCase(city)) {
					c.click();
					//System.out.println("City was loaded");
					break;
				}
			}
	//3.Choose the course list
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@class='card']/div/button/span")).click();
			Thread.sleep(2000);
			WebElement clist=driver.findElement(By.xpath("//*[@id='j_idt87:auto-complete_panel']/ul"));
			List<WebElement>CourceList=clist.findElements(By.tagName("li"));
			for(WebElement cource:CourceList) {
				System.out.println(cource.getText());
				if(cource.getText().equalsIgnoreCase("Selenium WebDriver")) {
					cource.click();
					break;
				}
			}
	//4.Choose language randomly
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='j_idt87:lang']/div[3]/span")).click();
			Thread.sleep(2000);
			WebElement lang=driver.findElement(By.xpath("//*[@id='j_idt87:lang_panel']/div/ul"));
			List<WebElement>lanuageList=lang.findElements(By.tagName("li"));
			int langcount=lanuageList.size();
			Random random= new Random();
			int rnm=random.nextInt(langcount);
			lanuageList.get(rnm).click();
	//5.Select 'Two' irrespective of the language chosen
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='j_idt87:value']/div[3]/span")).click();
			Thread.sleep(2000);
			WebElement resp=driver.findElement(By.xpath("//*[@id='j_idt87:value_items']"));
			List<WebElement>irrLang=resp.findElements(By.tagName("li"));
			String IrLang="രണ്ട്";
			for(WebElement r:irrLang) {
				System.out.println(r.getText());
				if(r.getText().equalsIgnoreCase(IrLang)) {
					r.click();
					break;
				}
			}
	
  }
}
