package Alert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SweetAlertHandsOn {
  @Test
  public void AlertHandsOn() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/alert.xhtml;jsessionid=node0qrunibgz7qa81fpoyomahyaip208166.node0");
	//Sweet Alert (Simple Dialog)
		driver.findElement(By.id("j_idt88:j_idt95")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='j_idt88:j_idt96']/div[3]/span/button/span")).click();
	//Sweet Modal Dialog
		driver.findElement(By.xpath("//*[@id='j_idt88:j_idt100']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='j_idt88:j_idt101']/div/a/span")).click();	
	//Sweet Alert (Confirmation)
		driver.findElement(By.id("j_idt88:j_idt106")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='j_idt88:j_idt107']/div[3]/button")).click();
	//Minimize and Maximize
		driver.findElement(By.id("j_idt88:j_idt111")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='j_idt88:j_idt112']/div/a[2]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='j_idt88:j_idt112']/div/a[3]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='j_idt88:j_idt112']/div/a[1]/span")).click();			
  }
}
