package Link;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Links {
  @Test
  public void HyperLinks() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/link.xhtml;jsessionid=node01nu0q9ndg6an0cxgqf5ic44mm200587.node0");
	//click the link by link text	
		driver.findElement(By.linkText("Go to Dashboard")).click();
		driver.navigate().back();
	//find the link destination without clicking link
		String destination=driver.findElement(By.linkText("Find the URL without clicking me.")).getAttribute("href");
		System.out.println(destination);
	//fiend the broken link
		driver.findElement(By.linkText("Broken?")).click();
		String ExpectedTitle="Error 404 /lists.xhtml Not Found in ExternalContext as a Resource";
		assertEquals(ExpectedTitle,driver.getTitle());
		driver.navigate().back();
	//count number of link
		List<WebElement>linkCount=driver.findElements(By.tagName("a"));
		System.out.println("Total link count : "+linkCount.size());
	//count layout links
		List<WebElement>linklayout=driver.findElements(By.xpath("//*[@class='card']/div/div/a"));
		System.out.println("Total Layout link count : "+linklayout.size());
	//count duplicate count
		List<WebElement>duplicate=driver.findElements(By.linkText("Go to Dashboard"));
		System.out.println("Total Duplicate link count : "+duplicate.size());
		
		
  }
}
