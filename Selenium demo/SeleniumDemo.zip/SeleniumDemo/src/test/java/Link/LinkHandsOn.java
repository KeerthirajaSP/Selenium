package Link;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LinkHandsOn {
  @Test
  public void LinkHandson() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/link.xhtml;jsessionid=node01nu0q9ndg6an0cxgqf5ic44mm200587.node0");
	//count duplicate count
		List<WebElement>duplicate=driver.findElements(By.linkText("Go to Dashboard"));
		System.out.println("Total Duplicate link count : "+duplicate.size());
  }
}
