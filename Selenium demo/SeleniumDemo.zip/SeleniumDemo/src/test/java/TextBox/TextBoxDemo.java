package TextBox;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TextBoxDemo {
	
		@Test
		public void f() throws InterruptedException {
	 

	 //Web driver portion
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	 
			WebDriver driver = new ChromeDriver();
	 
			driver.get("https://www.leafground.com/input.xhtml;jsessionid=node0bh7gd14t3lcg1ylgpinayj7878652.node0");
	 
	// using send key		
			driver.findElement(By.id("j_idt88:name")).sendKeys("Keerthiraja");
	 
	// clear text box
			driver.findElement(By.name("j_idt88:j_idt91")).clear();
	 
	// to check text box enable or not
			driver.findElement(By.name("j_idt88:j_idt91")).sendKeys(" India");
			boolean output=driver.findElement(By.id("j_idt88:j_idt93")).isEnabled();
			if(output==false) {
				System.out.println("text box is disabled");
			}
			
	// get the values from in side the text box
			String msginsidetextbox = driver.findElement(By.cssSelector("input[id='j_idt88:j_idt97']")).getAttribute("value");
			System.out.println(msginsidetextbox);
	 
	// passing the email id to the text box
			driver.findElement(By.xpath("//input[@id='j_idt88:j_idt99']")).sendKeys("keerthiraja.sp@hcl.com");
	 
	// using robot class to jump one text box to another 
			driver.findElement(By.xpath("//input[@id='j_idt88:j_idt99']")).sendKeys(Keys.TAB);
	 
			driver.findElement(By.xpath("//*[@id='j_idt88:j_idt103_toolbar']/span[1]/span[1]/span[1]")).click();
	 
			driver.findElement(By.xpath("//*[@id=\"ql-picker-options-0\"]/span[3]")).click();
	 
	// getting the error message after press enter button on text box 	
			driver.findElement(By.id("j_idt106:thisform:age")).sendKeys(Keys.ENTER);
			String msg=driver.findElement(By.xpath("//*[@id=\"j_idt106:thisform:j_idt110_error-detail\"]")).getText();
			System.out.println(msg);
			if(msg.equalsIgnoreCase("Age is mandatory")) {
				System.out.println("error msg displayed");
			}
			
	// get position of the element
			Point Location =driver.findElement(By.id("j_idt106:float-input")).getLocation();
			int x=Location.getX();
			int y=Location.getY();
			System.out.println("X axis : "+x +" y axis : "+ y);
			Thread.sleep(20000);
	 
	 // type your name and choose the listed option
			JavascriptExecutor js=(JavascriptExecutor)driver;
			
			//Step for scrolling down to pixel the web page
			js.executeScript("scrollBy(0,3000)");
			
			driver.findElement(By.id("j_idt106:auto-complete_input")).sendKeys("Keerthiraja");
			//driver.findElement(By.xpath("//*[@id='j_idt106:auto-complete_input']")).sendKeys("keerthiraja");
			Thread.sleep(20000);
			driver.findElement(By.xpath("//*[@id=\"j_idt106:auto-complete_panel\"]/ul/li[3]")).click();
	 
		}
	}

