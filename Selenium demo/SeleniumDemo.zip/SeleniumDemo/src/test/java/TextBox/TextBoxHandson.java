package TextBox;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TextBoxHandson {
	@BeforeMethod
	public void Before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");

	}
 @Test
  public void TextBoxUsingEnterFunction() {
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/input.xhtml;jsessionid=node012zfcirwzra2o2y497ixhmbze165081.node0");
	    driver.findElement(By.id("j_idt106:thisform:age")).sendKeys(Keys.ENTER);
	   String msg= driver.findElement(By.id("j_idt106:thisform:j_idt110_error-detail")).getText();
	   System.out.println(msg);
	   if(msg.equalsIgnoreCase("Age is mandatory")) {
			System.out.println("error msg displayed");
		}

	   	Point Before = driver.findElement(By.id("j_idt106:j_idt113")).getLocation();
		int x1= Before.getX();
		int y1= Before.getY();
		System.out.println( "Before location is " + " X axis : "+x1 +" and Y axis : "+ y1);
	    driver.findElement(By.id("j_idt106:float-input")).sendKeys("Keerthiraja");
	    Point After=driver.findElement(By.id("j_idt106:j_idt113")).getLocation();

		int x=After.getX();

		int y=After.getY();

		System.out.println( "After location is " + " X axis : "+x +" and Y axis : "+ y);
  }
 
  }
