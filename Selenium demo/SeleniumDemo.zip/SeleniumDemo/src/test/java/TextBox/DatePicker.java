package TextBox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DatePicker {
	@BeforeMethod
	public void Before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");

	}
	@Test
	  public void TextBoxDatePicker() {
		  WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://demo.automationtesting.in/Datepicker.html");
		
	//below x path is refers to text box disabled date picker
		
			driver.findElement(By.xpath("//*[@id='datepicker1']")).click();//clicking calendar icon
			//choosing previous month year and date
			for (int i= 12; i>=1; i--) {
				//below x path is used to find the previous button and click. 
				//i=12 is referred as how many month and year we move the past and click 12 times previous button 
				driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/a[1]")).click();
				//Below x path is used to refer month and year column
				String month=driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/div/span")).getText();
				// Below condition is month is equal to November then click the date
				if(month.equals("November")){
					driver.findElement(By.linkText("15")).click();
					break;
				}
			}
			//below path is text enabled Date Picker
			driver.findElement(By.xpath("//*[@id=\"datepicker2\"]")).sendKeys("04/10/1999");
	  }
}
