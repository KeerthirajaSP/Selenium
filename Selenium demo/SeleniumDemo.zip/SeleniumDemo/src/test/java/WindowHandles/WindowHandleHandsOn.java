package WindowHandles;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class WindowHandleHandsOn {
	@BeforeMethod
	public void Browser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	}
  @Test
  public void FindTheNumberOfOpenedTabs() {
	  
	    WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/window.xhtml");
		driver.getWindowHandle();
	//Find the number of opened tabs
		driver.findElement(By.id("j_idt88:j_idt91")).click();
		Set <String>s=driver.getWindowHandles();
		Iterator<String>I1=s.iterator();
		
		while(I1.hasNext()) {
			String ChildWindow=I1.next();
			driver.switchTo().window(ChildWindow);
			System.out.println(driver.getTitle()); 
		}
		System.out.println("the number of opened tabs : "+s.size());
		driver.quit();
  }
  @Test
  public void CloseAllWindowsExceptPrimary() {
	  	WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/window.xhtml");
		
	//Close all windows except Primary	
			
		driver.findElement(By.id("j_idt88:j_idt93")).click();
		Set <String>Primery=driver.getWindowHandles();
		Iterator<String>Iterator=Primery.iterator();
		
		while(Iterator.hasNext()) {	 
		String Child=Iterator.next();
		driver.switchTo().window(Child);
		System.out.println(driver.getTitle());
		}
		driver.quit();
  }
  @Test
  public void WaitFor2NewTabsToOpen () {
	 	WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/window.xhtml");
	//Wait for 2 new tabs to open
		driver.findElement(By.id("j_idt88:j_idt95")).click();
		driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
		Set <String>Tabopen=driver.getWindowHandles();
		Iterator<String>Iterator1=Tabopen.iterator();
		while (Iterator1.hasNext()) {
			String childWindow=Iterator1.next();
			String t=driver.switchTo().window(childWindow).getTitle();
			System.out.println(t);
		}
		driver.quit();
  }
}