package WindowHandles;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class WindowHandling {
  @Test
  public void window() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/window.xhtml");
		driver.getWindowHandle();
		System.out.println(driver.getTitle());
		driver.findElement(By.id("j_idt88:new")).click();
		Set <String>s=driver.getWindowHandles();
		Iterator<String>I1=s.iterator();
		I1.next();//first window
		String Window2=I1.next();//second window
		driver.switchTo().window(Window2);
		System.out.println(driver.getTitle());	
  }
}
