package AuthendicationPopup;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Authendication {
	@BeforeMethod
	public void Before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	}
  @Test
  public void AuthendicationMethod1() {
	  
	  	WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/auth.xhtml");
	//method 1:
		driver.get("https://admin:testleaf@leafground.com:8090/login");
		String A=driver.findElement(By.tagName("body")).getText();
		System.out.println(A);
  }
  @Test
  public void AuthendicationUsingRobotClass() throws AWTException {
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/auth.xhtml");
		driver.findElement(By.id("j_idt88:j_idt90")).click();
		String us="admin";
		StringSelection us1=new StringSelection(us);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(us1, null);
		
		Robot r1=new Robot();
		r1.delay(2000);
		r1.keyPress(KeyEvent.VK_CONTROL);
		r1.keyPress(KeyEvent.VK_V);
		r1.keyRelease(KeyEvent.VK_V);
		r1.keyRelease(KeyEvent.VK_CONTROL);
		r1.delay(2000);
		
		String psw="testleaf";
		StringSelection psw1=new StringSelection(psw);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(psw1, null);
		r1.keyPress(KeyEvent.VK_TAB);
		r1.keyPress(KeyEvent.VK_CONTROL);
		r1.keyPress(KeyEvent.VK_V);
		r1.keyRelease(KeyEvent.VK_V);
		r1.keyRelease(KeyEvent.VK_CONTROL);
		r1.delay(2000);
		r1.keyPress(KeyEvent.VK_ENTER);
		r1.keyRelease(KeyEvent.VK_ENTER);

		String msg=driver.findElement(By.tagName("body")).getText();
		System.out.println(msg);
  }
}
