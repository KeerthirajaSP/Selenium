package Frames;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class frameHandling {
  @Test
  public void frames() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/frame.xhtml;jsessionid=node010psmguq19e1j1u7ca3ntheyxp208926.node0");
	//Switching the frame by using index value frame(index)
		//Click Me (Inside frame)
		driver.switchTo().frame(0);
		driver.findElement(By.id("click")).click();
		driver.switchTo().defaultContent();// it will come back to default page
	//Switching the frame by using web element frame(web element)
		//Click Me (Inside Nested frame)
		WebElement frame1=driver.findElement(By.xpath("//*[@src='page.xhtml']"));
		driver.switchTo().frame(frame1);
	//Switching the frame by using name frame(name)	
		driver.switchTo().frame("frame2");
		driver.findElement(By.id("click")).click();
		driver.switchTo().defaultContent();
		//How many frames in this page?
		List<WebElement>frames=driver.findElements(By.tagName("iftame"));
		System.out.println(frames.size());
		
		
		
	  
  }
}
