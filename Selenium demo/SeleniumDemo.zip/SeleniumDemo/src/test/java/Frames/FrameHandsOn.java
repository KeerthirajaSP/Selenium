package Frames;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class FrameHandsOn {
  @Test
  public void FrameHandsOns() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\keerthiraja.sp\\Downloads\\SeleniumJarFiles\\chromedriver-win64\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://demo.automationtesting.in/Frames.html");
	  driver.switchTo().frame("singleframe");
	  WebElement Iframe=driver.findElement(By.xpath("/html/body/section/div/h5"));
      System.out.println(Iframe.getText());
      driver.findElement(By.xpath("//*[@class='col-xs-6 col-xs-offset-5']/input")).sendKeys("Hello");
      Thread.sleep(2000);
      
      driver.switchTo().defaultContent();
      driver.findElement(By.xpath("//*[@class='nav nav-tabs ']/li[2]")).click();
      WebElement Nested=driver.findElement(By.xpath("//*[@src='MultipleFrames.html']"));
      driver.switchTo().frame(Nested);
     
     WebElement Innerframe=driver.findElement(By.xpath("//*[@src='SingleFrame.html']"));
     driver.switchTo().frame(Innerframe);
     driver.findElement(By.xpath("//*[@class='col-xs-6 col-xs-offset-5']/input")).sendKeys("Hello");
  }
}
